#!/usr/bin/env node
/**
 * PERFUMUM Phase 1B — inventory preparation only.
 *
 * This program permits SELECT queries against the configured source database and
 * writes CSV/JSON/Markdown planning artifacts locally. It never creates, alters,
 * deletes, locks, updates or exports production table data.
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import mysql from "mysql2/promise";

const outputRoot = path.resolve(process.argv[2] ?? path.join(import.meta.dirname, ".."));
const projectRoot = path.resolve(process.argv[3] ?? path.join(outputRoot, "../.."));
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required for a read-only metadata inventory.");

function mkdir(relative) {
  const absolute = path.join(outputRoot, relative);
  fs.mkdirSync(absolute, { recursive: true });
  return absolute;
}
function write(relative, content) {
  const target = path.join(outputRoot, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content, "utf8");
}
function jsonText(value) { return JSON.stringify(value, null, 2) + "\n"; }
function cell(value) {
  if (value === null || value === undefined) return "";
  const text = typeof value === "object" ? JSON.stringify(value) : String(value);
  return `"${text.replaceAll('"', '""')}"`;
}
function csv(rows, headers = rows.length ? Object.keys(rows[0]) : []) {
  return `${headers.join(",")}\n${rows.map((row) => headers.map((header) => cell(row[header])).join(",")).join("\n")}${rows.length ? "\n" : ""}`;
}
function sha256(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function quoteId(identifier) { return `\`${String(identifier).replaceAll("`", "``")}\``; }
function ensureReadOnly(sql) {
  const normalized = sql.replace(/^\s*(?:\/\*[\s\S]*?\*\/\s*)*/u, "").trim().toUpperCase();
  if (!normalized.startsWith("SELECT") && !normalized.startsWith("SHOW")) {
    throw new Error(`Refusing non-read-only SQL: ${normalized.slice(0, 48)}`);
  }
}
async function query(conn, sql, values = []) {
  ensureReadOnly(sql);
  return (await conn.query(sql, values))[0];
}
function walk(directory) {
  if (!fs.existsSync(directory)) return [];
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else files.push(full);
  }
  return files;
}
function drizzleTableNames() {
  const names = new Set();
  const schemaFiles = [
    path.join(projectRoot, "drizzle", "schema.ts"),
    ...walk(path.join(projectRoot, "drizzle", "schema-modules")).filter((file) => file.endsWith(".ts")),
  ];
  for (const file of schemaFiles) {
    const source = fs.readFileSync(file, "utf8");
    for (const match of source.matchAll(/mysqlTable\s*\(\s*["']([^"']+)["']/gu)) names.add(match[1]);
  }
  return names;
}
function migrationFilesFor(table) {
  const escaped = table.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  const found = [];
  for (const file of fs.readdirSync(path.join(projectRoot, "drizzle")).filter((name) => name.endsWith(".sql")).sort()) {
    const source = fs.readFileSync(path.join(projectRoot, "drizzle", file), "utf8");
    if (source.includes(`\`${table}\``) || new RegExp(`\\b${escaped}\\b`, "u").test(source)) found.push(file);
  }
  return found;
}
const contains = (name, pattern) => pattern.test(name.toLowerCase());
function relationByStructure(table, columns, foreignKeys) {
  const name = table.toLowerCase();
  if (/(^|_)(links?|relations?|associations?|mappings?)(_|$)/u.test(name)) return true;
  if (/^(plant|molecule|tabac|tobacco|recipe|recette|bibliography|reference|evidence|source|family|accord|terroir|prototype|installation|laboratoire|petrichor|volcanique|terp_profile).*_(molecules?|plants?|recettes?|recipes?|families|accords?|terroirs?|references?|sources?|axes|tags|profiles?|analytical_methods|chemical_families|origins|perfumes|synergies)$/u.test(name)) return true;
  // Chemical identifiers such as pubchem_cid and wikidata_qid are not relational
  // keys. Only explicit foreign keys, or an unambiguous junction name, are used.
  const hasPrimaryKey = columns.some((column) => column.column_key === "PRI");
  return foreignKeys.length >= 2 && !hasPrimaryKey;
}
function classify(table, columns, foreignKeys) {
  const name = table.toLowerCase();
  const columnNames = columns.map((column) => column.column_name.toLowerCase());
  const has = (...terms) => terms.some((term) => name.includes(term) || columnNames.some((column) => column.includes(term)));
  const exact = {
    accords: ["recherche", "entité d’accord olfactif identifiée"],
    accord_civilisations: ["relation", "table de liaison accord–civilisation nommée"],
    aromatic_accords: ["recherche", "corpus d’accords aromatiques identifié"],
    extraction_tests: ["recherche", "résultats d’essais d’extraction identifiés"],
    ifra_categories: ["référentiel", "catégories IFRA identifiées"],
    molecules: ["recherche", "entité moléculaire centrale identifiée"],
    plants: ["recherche", "entité botanique centrale identifiée"],
    raw_materials: ["recherche", "entité matière première identifiée"],
    recettes: ["recherche", "entité recette/formulation centrale identifiée"],
    protocol_steps: ["recherche", "étapes ordonnées de protocole documentées"],
    recherche_radicale: ["recherche", "corpus de recherche nommé"],
    sensory_scales: ["référentiel", "échelles sensorielles identifiées"],
    situated_smells: ["recherche", "observations olfactives situées identifiées"],
    sparql_saved_queries: ["application", "requêtes sauvegardées et endpoint applicatif identifiés"],
    technical_protocols: ["recherche", "protocoles techniques identifiés"],
    terroirs: ["recherche", "entité territoriale centrale identifiée"],
    tabacs: ["recherche", "entité tabac centrale identifiée"],
  };
  if (exact[name]) return { category: exact[name][0], rule: exact[name][1] };
  if (/^(tmp|temp|staging|test|backup|bak|old|legacy|orphan|unknown|shadow)_/u.test(name)) return { category: "inconnue", rule: "préfixe de sécurité : état temporaire/historique non prouvé" };
  if (table === "__drizzle_migrations") return { category: "historique", rule: "journal de migrations explicitement identifié" };
  if (has("cache") || (has("query_hash", "results_json", "expires_at") && has("query"))) return { category: "cache", rule: "résultat dérivé/expirable identifié" };
  if (/^(?:__drizzle_migrations|modification_history|classification_snapshots|descriptor_link_audit_log|recipe_versions)$/u.test(name) || /(?:^|_)(audit|remediation)(?:_|$)/u.test(name)) return { category: "historique", rule: "trace technique, de version ou de remédiation identifiée par le nom de table" };
  if (relationByStructure(table, columns, foreignKeys)) return { category: "relation", rule: "liaison nommée ou table portant au moins deux clés étrangères explicites" };
  if (/(bibliograph|citation|reference|publication)/u.test(name)
    || columnNames.some((column) => /^(doi|isbn|issn|pmid|pmcid)$/u.test(column))) return { category: "bibliographie", rule: "notice, source, auteur ou citation identifiée" };
  if (/(image|images|media|asset|assets|photo|photos|upload|uploads|files?)$/u.test(name) || has("file_key", "mime_type", "file_size")) return { category: "média", rule: "table centrée sur un actif/fichier ou portant les métadonnées natives d’un binaire" };
  if (has("descriptor", "family", "families", "axis", "axes", "taxonomy", "glossary", "method", "zone", "tradition", "state")) return { category: "référentiel", rule: "vocabulaire, méthode, taxonomie ou référentiel identifié" };
  if (has("user", "notification", "analytics", "collection", "contribution", "inventory", "gestion", "agenda", "budget", "supplier", "partner", "api_")) return { category: "application", rule: "compte, administration, contribution, fournisseur ou état applicatif identifié" };
  if (has("plant", "molecule", "terroir", "recipe", "recette", "tabac", "tobacco", "cannabis", "gcms", "chromat", "spectra", "olfact", "scent", "odor", "fermentation", "perique", "herbarium", "soil", "climate", "research", "projet", "installation", "prototype", "laboratoire", "civilization", "genome", "gene", "tps", "trade", "variety", "landrace", "petrichor", "volcanique")) return { category: "recherche", rule: "entité ou corpus scientifique/culturel/expérimental identifié" };
  return { category: "inconnue", rule: "fonction non prouvable par le nom, la structure ou le code local" };
}
function sensitivity(table, columns) {
  const name = table.toLowerCase();
  const fields = columns.map((column) => column.column_name.toLowerCase());
  const has = (...terms) => terms.some((term) => name.includes(term) || fields.some((field) => field.includes(term)));
  if (has("openid", "email", "phone", "address", "contact", "first_name", "last_name", "full_name", "user_id", "creator_id", "created_by", "added_by", "uploaded_by", "reviewed_by", "verified_by", "read_by", "contributor", "researcher", "author")) {
    return { level: "potentiellement personnelle", rationale: "identifiant, attribution de personne ou moyen de contact structurellement présent" };
  }
  if (has("token", "secret", "password", "internal_note", "admin_note", "personal_note", "state_before", "state_after", "price", "cost", "budget", "stock", "formula", "file_key", "file_url", "share")) {
    return { level: "potentiellement privée", rationale: "contenu interne, commercial, partage, formule, fichier ou état opérationnel possible" };
  }
  if (fields.some((field) => /^(metadata|content|data|payload|config|settings|notes|details|json)$/u.test(field)) || columns.some((column) => column.data_type.toLowerCase() === "json")) {
    return { level: "à vérifier", rationale: "champ libre ou JSON pouvant contenir des informations non caractérisées" };
  }
  return { level: "aucune apparente", rationale: "aucun indicateur structurel de donnée personnelle ou privée observé" };
}
function rightsAndInclusion(category, sensitive, columns) {
  const fields = columns.map((column) => column.column_name.toLowerCase());
  const isMedia = category === "média";
  const isCache = category === "cache";
  const hasToken = fields.some((field) => /(token|secret|password|cookie|session)/u.test(field));
  if (hasToken) return { rights: "restriction technique : secret/session potentiel ; ne pas exporter avant examen des colonnes", inclusion: "exclure_du_premier_export", rationale: "risque de secret ou de session" };
  if (sensitive.level === "potentiellement personnelle") return { rights: "données personnelles potentielles : base légale, minimisation et chiffrement à confirmer", inclusion: "inclure_chiffré_après_approbation", rationale: "données de compte, attribution ou contact potentiellement présents" };
  if (isMedia) return { rights: "droits de copie et de redistribution à vérifier par objet ; métadonnées séparées des binaires", inclusion: "inclure_métadonnées ; binaires_après_permission", rationale: "l’URL ou la clé ne prouve ni l’accès ni le droit de copie" };
  if (isCache) return { rights: "donnée dérivée/regénérable ; droits de la source amont à vérifier si elle est conservée", inclusion: "différer", rationale: "cache non requis pour restaurer le noyau relationnel" };
  if (sensitive.level === "potentiellement privée") return { rights: "contenu potentiellement interne/privé : revue propriétaire et chiffrement requis", inclusion: "révision_humaine", rationale: "risque de contenu interne ou commercial" };
  if (sensitive.level === "à vérifier") return { rights: "droits et contenu à confirmer avant diffusion ; export chiffré recommandé", inclusion: "révision_humaine", rationale: "champs libres ou JSON non qualifiés" };
  return { rights: "droit de diffusion non documenté ; conserver dans une archive contrôlée, pas de publication automatique", inclusion: "inclure", rationale: "donnée nécessaire au corpus ou à sa structure, sans signal structurel de sensibilité" };
}
function flattenColumns(columns) {
  return columns.map((column) => `${column.column_name}:${column.column_type}${column.is_nullable === "NO" ? " NOT NULL" : ""}${column.column_default === null ? "" : ` DEFAULT=${column.column_default}`}`).join(" | ");
}
function valueOrDash(value) { return value || "—"; }

mkdir("inventory");
const conn = await mysql.createConnection(process.env.DATABASE_URL);
try {
  const capturedAt = new Date().toISOString();
  const versionRows = await query(conn, "SELECT VERSION() AS server_version, DATABASE() AS database_name, @@time_zone AS session_time_zone, @@system_time_zone AS system_time_zone");
  const database = versionRows[0];
  const tables = await query(conn, `SELECT table_name, table_rows, data_length, index_length, table_collation, create_time, update_time
    FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
    ORDER BY table_name`);
  const views = await query(conn, `SELECT table_name FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_type = 'VIEW' ORDER BY table_name`);
  const columns = await query(conn, `SELECT c.table_name, c.column_name, c.ordinal_position, c.column_default, c.is_nullable, c.data_type, c.column_type, c.column_key, c.extra, c.character_set_name, c.collation_name
    FROM information_schema.columns c INNER JOIN information_schema.tables t
    ON t.table_schema=c.table_schema AND t.table_name=c.table_name
    WHERE c.table_schema=DATABASE() AND t.table_type='BASE TABLE'
    ORDER BY c.table_name, c.ordinal_position`);
  const constraints = await query(conn, `SELECT tc.table_name, tc.constraint_name, tc.constraint_type, kcu.column_name, kcu.referenced_table_name, kcu.referenced_column_name, kcu.ordinal_position
    FROM information_schema.table_constraints tc
    LEFT JOIN information_schema.key_column_usage kcu
      ON tc.constraint_schema=kcu.constraint_schema AND tc.table_name=kcu.table_name AND tc.constraint_name=kcu.constraint_name
    WHERE tc.table_schema=DATABASE()
    ORDER BY tc.table_name, tc.constraint_name, kcu.ordinal_position`);
  const stats = await query(conn, `SELECT table_name, index_name, non_unique, seq_in_index, column_name, index_type
    FROM information_schema.statistics WHERE table_schema=DATABASE()
    ORDER BY table_name, index_name, seq_in_index`);
  const drizzle = drizzleTableNames();
  const byTable = new Map(tables.map((table) => [table.table_name, { columns: [], constraints: [], stats: [] }]));
  for (const row of columns) byTable.get(row.table_name)?.columns.push(row);
  for (const row of constraints) byTable.get(row.table_name)?.constraints.push(row);
  for (const row of stats) byTable.get(row.table_name)?.stats.push(row);

  const matrix = tables.map((table) => {
    const detail = byTable.get(table.table_name);
    const pk = detail.constraints.filter((row) => row.constraint_type === "PRIMARY KEY");
    const fk = detail.constraints.filter((row) => row.constraint_type === "FOREIGN KEY");
    const uniques = detail.constraints.filter((row) => row.constraint_type === "UNIQUE");
    const typeInfo = classify(table.table_name, detail.columns, fk);
    const sensitive = sensitivity(table.table_name, detail.columns);
    const exportDecision = rightsAndInclusion(typeInfo.category, sensitive, detail.columns);
    const migrations = migrationFilesFor(table.table_name);
    const indexes = new Map();
    for (const stat of detail.stats) {
      const record = indexes.get(stat.index_name) ?? { index_name: stat.index_name, unique: Number(stat.non_unique) === 0, index_type: stat.index_type, columns: [] };
      record.columns.push(stat.column_name);
      indexes.set(stat.index_name, record);
    }
    const rowSize = Number(table.data_length ?? 0) + Number(table.index_length ?? 0);
    return {
      table_reelle: table.table_name,
      lignes_estimees_information_schema: Number(table.table_rows ?? 0),
      data_bytes_estimes: Number(table.data_length ?? 0),
      index_bytes_estimes: Number(table.index_length ?? 0),
      taille_bytes_estimee: rowSize,
      taille_mib_estimee: Number((rowSize / 1024 / 1024).toFixed(3)),
      collation: valueOrDash(table.table_collation),
      colonnes_et_types: flattenColumns(detail.columns),
      nombre_colonnes: detail.columns.length,
      contient_json: detail.columns.some((column) => column.data_type.toLowerCase() === "json") ? "oui" : "non",
      cle_primaire: pk.length ? [...new Set(pk.map((row) => row.column_name))].join(" | ") : "aucune",
      sans_cle_primaire: pk.length ? "non" : "oui",
      cles_etrangeres: fk.length ? fk.map((row) => `${row.column_name}->${row.referenced_table_name}.${row.referenced_column_name}`).join(" | ") : "aucune",
      contraintes_uniques: uniques.length ? uniques.map((row) => `${row.constraint_name}:${row.column_name ?? ""}`).join(" | ") : "aucune",
      index: [...indexes.values()].map((index) => `${index.index_name}${index.unique ? " [unique]" : ""}:${index.columns.join("+")}`).join(" | ") || "aucun",
      drizzle: drizzle.has(table.table_name) ? "présente" : "absente",
      migrations_sql: migrations.length ? `mentionnée (${migrations.length})` : "non détectée",
      fichiers_migration: migrations.join(" | ") || "—",
      categorie_proposee: typeInfo.category,
      regle_categorie: typeInfo.rule,
      sensibilite_potentielle: sensitive.level,
      justification_sensibilite: sensitive.rationale,
      droits_restrictions_connus: exportDecision.rights,
      inclusion_recommandee: exportDecision.inclusion,
      justification_inclusion: exportDecision.rationale,
      created_at_source: table.create_time ? new Date(table.create_time).toISOString() : "—",
      updated_at_source: table.update_time ? new Date(table.update_time).toISOString() : "—",
    };
  });

  const databaseBytes = matrix.reduce((sum, row) => sum + row.taille_bytes_estimee, 0);
  const summary = {
    generated_at_utc: capturedAt,
    method: "information_schema read-only; table_rows and data/index lengths are database estimates, not full COUNT(*) measurements",
    source: { database_name: database.database_name, server_version: database.server_version, session_time_zone: database.session_time_zone, system_time_zone: database.system_time_zone },
    base_tables: matrix.length,
    views_excluded_from_matrix: views.map((view) => view.table_name),
    columns: columns.length,
    constraints: new Set(constraints.map((row) => `${row.table_name}:${row.constraint_name}`)).size,
    foreign_key_column_rows: constraints.filter((row) => row.constraint_type === "FOREIGN KEY").length,
    estimated_database_bytes_data_plus_indexes: databaseBytes,
    estimated_database_mib_data_plus_indexes: Number((databaseBytes / 1024 / 1024).toFixed(3)),
    drizzle_declared_tables: drizzle.size,
    drizzle_intersection: matrix.filter((row) => row.drizzle === "présente").length,
    migration_sql_files: fs.readdirSync(path.join(projectRoot, "drizzle")).filter((name) => name.endsWith(".sql")).length,
    tables_without_primary_key: matrix.filter((row) => row.sans_cle_primaire === "oui").map((row) => row.table_reelle),
    category_counts: Object.fromEntries([...new Set(matrix.map((row) => row.categorie_proposee))].sort().map((category) => [category, matrix.filter((row) => row.categorie_proposee === category).length])),
    sensitivity_counts: Object.fromEntries([...new Set(matrix.map((row) => row.sensibilite_potentielle))].sort().map((level) => [level, matrix.filter((row) => row.sensibilite_potentielle === level).length])),
    inclusion_counts: Object.fromEntries([...new Set(matrix.map((row) => row.inclusion_recommandee))].sort().map((status) => [status, matrix.filter((row) => row.inclusion_recommandee === status).length])),
  };

  const isBinaryCandidate = (column) => /^(file_key|file_url|file_name|file_size|mime_type|image_url|photo_url|cover_image_url|thumbnail_url|thumbnail_url_large|scan_url|data_file|raw_data_url|report_url|chromatogram_url|map_url|assets)$/iu.test(column.column_name)
    || /(?:^|_)(image|images|media|asset|assets|photo|photos|thumbnail|upload|uploads|scan)(?:_|$)/iu.test(column.column_name);
  const mediaColumns = columns.filter(isBinaryCandidate);
  const mediaTableInventory = [];
  const mediaObjects = [];
  for (const [tableName, group] of Object.entries(Object.groupBy(mediaColumns, (column) => column.table_name))) {
    const tableColumns = byTable.get(tableName).columns;
    const pkColumns = tableColumns.filter((column) => column.column_key === "PRI").map((column) => column.column_name);
    const candidateColumns = group.map((column) => column.column_name);
    const optional = ["mime_type", "file_size", "source", "source_url", "attribution", "is_verified", "uploaded_by", "created_at"].filter((name) => tableColumns.some((column) => column.column_name === name));
    const selected = [...new Set([...pkColumns, ...candidateColumns, ...optional])];
    const nonEmpty = candidateColumns.map((column) => `(${quoteId(column)} IS NOT NULL AND CAST(${quoteId(column)} AS CHAR) <> '')`).join(" OR ");
    const sql = `SELECT ${selected.map(quoteId).join(", ")} FROM ${quoteId(tableName)} WHERE ${nonEmpty}`;
    const rows = await query(conn, sql);
    mediaTableInventory.push({
      table_reelle: tableName,
      colonnes_media_candidates: candidateColumns.join(" | "),
      lignes_referencees: rows.length,
      cle_primaire: pkColumns.join(" | ") || "aucune",
      statut: "références lues sans téléchargement de binaire",
    });
    for (const row of rows) {
      const locator = pkColumns.length ? pkColumns.map((column) => `${column}=${row[column]}`).join(";") : `sha256:${sha256(JSON.stringify(row))}`;
      const available = candidateColumns.filter((column) => row[column] !== null && row[column] !== undefined && String(row[column]) !== "");
      mediaObjects.push({
        table_reelle: tableName,
        reference_ligne: locator,
        colonnes_referencees: available.join(" | "),
        emplacement_declared: available.map((column) => `${column}=${row[column]}`).join(" | "),
        mime_type: row.mime_type ?? "non documenté",
        taille_declaree_octets: row.file_size ?? "non documentée",
        source: row.source ?? "non documentée",
        source_url: row.source_url ?? "non documentée",
        attribution: row.attribution ?? "non documentée",
        statut_accessibilite: "non testée — aucune requête Forge ni téléchargement binaire",
        droits_connus: "à vérifier par objet ; référence/URL/attribution insuffisantes pour conclure au droit de copie",
        statut_recuperation: "inventorié seulement",
        restriction: "permission propriétaire + accès lecture Forge + examen licence requis avant copie binaire",
      });
    }
  }

  write("inventory/table-recovery-matrix.csv", csv(matrix));
  write("inventory/table-recovery-matrix.json", jsonText(matrix));
  write("inventory/media-table-inventory.csv", csv(mediaTableInventory));
  write("inventory/media-reference-inventory.csv", csv(mediaObjects));
  write("inventory/inventory-summary.json", jsonText(summary));
  write("inventory/source-catalogue-sha256.txt", `${sha256(JSON.stringify({ tables, columns, constraints, stats }))}  information_schema_catalogue_canonical.json\n`);
} finally {
  await conn.end();
}

#!/usr/bin/env node
/**
 * Recovery Proof v0.1 — export read-only and deliberately small.
 *
 * Reads the existing TiDB/MySQL database through DATABASE_URL and writes an
 * isolated proof corpus. It never issues DDL/DML against the source database.
 * Do not point DATABASE_URL to a database whose data must not be read.
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import mysql from "mysql2/promise";

const root = path.resolve(process.argv[2] ?? path.join(import.meta.dirname, ".."));
const projectRoot = path.resolve(process.argv[3] ?? path.join(root, "../.."));
const proofPlantId = 480029;
const selectedTables = [
  "plants",
  "molecules",
  "terroirs",
  "plant_molecules",
  "plant_terroirs",
  "bibliography_entries",
  "bibliography_entity_links",
];

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required to create this recovery proof.");
}

function mkdir(relative) {
  const absolute = path.join(root, relative);
  fs.mkdirSync(absolute, { recursive: true });
  return absolute;
}

function write(relative, content) {
  const absolute = path.join(root, relative);
  fs.mkdirSync(path.dirname(absolute), { recursive: true });
  fs.writeFileSync(absolute, content, "utf8");
}

function csvValue(value) {
  if (value === null || value === undefined) return "";
  const text = value instanceof Date
    ? value.toISOString()
    : (typeof value === "object" ? JSON.stringify(value, jsonReplacer) : String(value));
  return `"${text.replaceAll('"', '""')}"`;
}

function asCsv(rows) {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]);
  return `${headers.join(",")}\n${rows.map((row) => headers.map((header) => csvValue(row[header])).join(",")).join("\n")}\n`;
}

function jsonReplacer(_key, value) {
  if (typeof value === "bigint") return value.toString();
  if (value instanceof Date) return value.toISOString();
  if (Buffer.isBuffer(value)) return { encoding: "base64", data: value.toString("base64") };
  return value;
}

function jsonText(value) {
  return JSON.stringify(value, jsonReplacer, 2) + "\n";
}

function jsonl(rows) {
  return rows.map((row) => JSON.stringify(row, jsonReplacer)).join("\n") + (rows.length ? "\n" : "");
}

function sqlValue(value) {
  if (value === null || value === undefined) return "NULL";
  if (typeof value === "number" || typeof value === "bigint") return String(value);
  if (value instanceof Date) return `'${value.toISOString().replace("T", " ").replace("Z", "")}'`;
  if (Buffer.isBuffer(value)) return `X'${value.toString("hex")}'`;
  const text = typeof value === "object" ? JSON.stringify(value, jsonReplacer) : String(value);
  return `'${text.replaceAll("\\", "\\\\").replaceAll("'", "\\'").replaceAll("\0", "\\0").replaceAll("\n", "\\n").replaceAll("\r", "\\r")}'`;
}

function insertStatements(table, rows) {
  if (!rows.length) return `-- ${table}: no selected rows\n`;
  const columns = Object.keys(rows[0]);
  const columnList = columns.map((column) => `\`${column}\``).join(", ");
  const values = rows.map((row) => `(${columns.map((column) => sqlValue(row[column])).join(", ")})`).join(",\n");
  return `INSERT INTO \`${table}\` (${columnList}) VALUES\n${values};\n`;
}

function sha256(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  const result = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) result.push(...walk(full));
    else result.push(full);
  }
  return result;
}

function drizzleTables() {
  const result = new Set();
  for (const file of [
    path.join(projectRoot, "drizzle", "schema.ts"),
    ...walk(path.join(projectRoot, "drizzle", "schema-modules")).filter((name) => name.endsWith(".ts")),
  ]) {
    const text = fs.readFileSync(file, "utf8");
    for (const match of text.matchAll(/mysqlTable\s*\(\s*["']([^"']+)["']/g)) result.add(match[1]);
  }
  return result;
}

function migrationMentions(table) {
  for (const file of fs.readdirSync(path.join(projectRoot, "drizzle")).filter((name) => name.endsWith(".sql"))) {
    const content = fs.readFileSync(path.join(projectRoot, "drizzle", file), "utf8");
    if (content.includes(`\`${table}\``) || new RegExp(`\\b${table.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(content)) return "mentionnée";
  }
  return "non détectée";
}

const connection = await mysql.createConnection(process.env.DATABASE_URL);
try {
  const [[databaseVersion]] = await connection.query("SELECT VERSION() AS version, DATABASE() AS database_name");
  const [tableInventory] = await connection.query(`
    SELECT table_name, table_type, table_rows, data_length, index_length, create_time, update_time
    FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
    ORDER BY table_name
  `);
  const [[viewCount]] = await connection.query(`
    SELECT COUNT(*) AS total FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_type = 'VIEW'
  `);
  const [columnInventory] = await connection.query(`
    SELECT c.table_name, c.column_name, c.ordinal_position, c.column_default, c.is_nullable, c.data_type, c.column_type, c.column_key, c.extra
    FROM information_schema.columns c
    INNER JOIN information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name
    WHERE c.table_schema = DATABASE() AND t.table_type = 'BASE TABLE'
    ORDER BY c.table_name, c.ordinal_position
  `);
  const [constraintInventory] = await connection.query(`
    SELECT tc.table_name, tc.constraint_name, tc.constraint_type, kcu.column_name,
           kcu.referenced_table_name, kcu.referenced_column_name
    FROM information_schema.table_constraints tc
    LEFT JOIN information_schema.key_column_usage kcu
      ON tc.constraint_schema = kcu.constraint_schema
     AND tc.table_name = kcu.table_name
     AND tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = DATABASE()
    ORDER BY tc.table_name, tc.constraint_name, kcu.ordinal_position
  `);
  const [[constraintCount]] = await connection.query(`
    SELECT COUNT(*) AS total
    FROM information_schema.table_constraints
    WHERE table_schema = DATABASE()
  `);

  const sample = {
    plants: (await connection.query("SELECT * FROM plants WHERE id=?", [proofPlantId]))[0],
    plant_molecules: (await connection.query("SELECT * FROM plant_molecules WHERE plant_id=?", [proofPlantId]))[0],
    plant_terroirs: (await connection.query("SELECT * FROM plant_terroirs WHERE plant_id=?", [proofPlantId]))[0],
  };
  const moleculeIds = sample.plant_molecules.map((row) => row.molecule_id);
  const terroirIds = sample.plant_terroirs.map((row) => row.terroir_id);
  sample.molecules = moleculeIds.length
    ? (await connection.query(`SELECT * FROM molecules WHERE id IN (${moleculeIds.map(() => "?").join(",")}) ORDER BY id`, moleculeIds))[0]
    : [];
  sample.terroirs = terroirIds.length
    ? (await connection.query(`SELECT * FROM terroirs WHERE id IN (${terroirIds.map(() => "?").join(",")}) ORDER BY id`, terroirIds))[0]
    : [];
  sample.bibliography_entity_links = (await connection.query(
    "SELECT * FROM bibliography_entity_links WHERE entity_type='plant' AND entity_id=? ORDER BY id",
    [proofPlantId],
  ))[0];
  const bibliographyIds = sample.bibliography_entity_links.map((row) => row.bibliography_id);
  sample.bibliography_entries = bibliographyIds.length
    ? (await connection.query(`SELECT * FROM bibliography_entries WHERE id IN (${bibliographyIds.map(() => "?").join(",")}) ORDER BY id`, bibliographyIds))[0]
    : [];

  for (const table of selectedTables) {
    if (!Array.isArray(sample[table])) throw new Error(`Missing sample selection for ${table}`);
  }

  mkdir("database/sample");
  mkdir("database/schema");
  mkdir("database/information-schema");
  mkdir("assets");
  mkdir("code-excerpt");
  mkdir("configuration");

  let schemaSql = "-- Recovery Proof v0.1: DDL captured read-only from the source database.\n-- This is an isolated, seven-table sample; it is not a canonical migration history.\nSET FOREIGN_KEY_CHECKS=0;\n\n";
  for (const table of selectedTables) {
    const [definition] = await connection.query(`SHOW CREATE TABLE \`${table}\``);
    schemaSql += `-- Source table: ${table}\n${definition[0]["Create Table"]};\n\n`;
  }
  schemaSql += "SET FOREIGN_KEY_CHECKS=1;\n";
  write("database/schema/sample-schema.sql", schemaSql);

  let dataSql = "-- Recovery Proof v0.1: 21 selected non-user rows from plant ID 480029.\n-- Generated from read-only SELECT queries; no source data was changed.\nSET FOREIGN_KEY_CHECKS=0;\n\n";
  for (const table of ["plants", "molecules", "terroirs", "plant_molecules", "plant_terroirs", "bibliography_entries", "bibliography_entity_links"]) {
    dataSql += `-- ${table}\n${insertStatements(table, sample[table])}\n`;
  }
  dataSql += "SET FOREIGN_KEY_CHECKS=1;\n";
  write("database/sample/sample-data.sql", dataSql);

  for (const [table, rows] of Object.entries(sample)) {
    write(`database/sample/${table}.csv`, asCsv(rows));
    write(`database/sample/${table}.jsonl`, jsonl(rows));
  }

  write("database/information-schema/tables.csv", asCsv(tableInventory));
  write("database/information-schema/columns.csv", asCsv(columnInventory));
  write("database/information-schema/constraints.csv", asCsv(constraintInventory));
  write("database/information-schema/summary.json", jsonText({
    source: "information_schema, read-only",
    captured_at_utc: new Date().toISOString(),
    database: databaseVersion.database_name,
    server_version: databaseVersion.version,
    base_tables: tableInventory.length,
    views_excluded_from_matrix: Number(viewCount.total),
    columns_in_base_tables: columnInventory.length,
    constraints: Number(constraintCount.total),
    constraint_column_rows: constraintInventory.length,
  }));

  const declared = drizzleTables();
  const role = {
    plants: "botanique", molecules: "chimie", terroirs: "territoire", plant_molecules: "relation plante–molécule",
    plant_terroirs: "relation plante–terroir", bibliography_entries: "bibliographie", bibliography_entity_links: "liaison bibliographique",
  };
  const matrix = tableInventory.map((row) => ({
    table_reelle: row.table_name,
    drizzle: declared.has(row.table_name) ? "déclarée" : "absente",
    migration: migrationMentions(row.table_name),
    donnees_estimees: row.table_rows,
    role_connu: role[row.table_name] ?? "à documenter",
    statut: declared.has(row.table_name) ? "réelle + Drizzle" : "réelle seulement",
  }));
  write("database/table-coverage-matrix.csv", asCsv(matrix));

  const [imageRows] = await connection.query(`
    SELECT id, file_key, file_name, mime_type, file_size, source, source_url, attribution,
           plant_id, terroir_id, quality, is_verified
    FROM variety_images ORDER BY id
  `);
  write("assets/variety-images-reference-inventory.csv", asCsv(imageRows));
  write("assets/README-ASSETS.md", `# Inventaire initial des assets\n\nCet inventaire provient uniquement de la table \`variety_images\`, lue sans téléchargement ni copie des objets. Il contient ${imageRows.length} références. Les clés et URLs peuvent dépendre de Forge/Manus ; leur présence ne prouve ni l’accessibilité actuelle, ni le droit de redistribution. Aucun média n’est inclus dans Recovery Proof v0.1.\n`);

  const sourceFile = path.join(projectRoot, "server", "routers", "data-quality-remediation.ts");
  const excerpt = fs.readFileSync(sourceFile, "utf8").split("\n").slice(0, 140).join("\n") + "\n";
  write("code-excerpt/data-quality-remediation.ts", excerpt);

  const configFiles = [
    "package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml", "vite.config.ts", "vitest.config.ts", "drizzle.config.ts",
    "tsconfig.json", "tsconfig.check.json", "tsconfig.server-only.json", ".gitignore", ".dockerignore",
  ];
  for (const relative of configFiles) {
    const source = path.join(projectRoot, relative);
    if (fs.existsSync(source)) fs.copyFileSync(source, path.join(root, "configuration", relative));
  }

  const envNames = new Set();
  for (const file of [
    ...walk(path.join(projectRoot, "server")),
    ...walk(path.join(projectRoot, "client")),
  ].filter((name) => /\.(ts|tsx|mjs|js)$/.test(name))) {
    const text = fs.readFileSync(file, "utf8");
    for (const match of text.matchAll(/process\.env\.([A-Z][A-Z0-9_]+)/g)) envNames.add(match[1]);
  }
  for (const name of [
    "VITE_APP_ID", "JWT_SECRET", "DATABASE_URL", "OAUTH_SERVER_URL", "OWNER_OPEN_ID",
    "BUILT_IN_FORGE_API_URL", "BUILT_IN_FORGE_API_KEY", "VITE_FRONTEND_FORGE_API_KEY",
  ]) envNames.add(name);
  const envText = [
    "# Recovery Proof v0.1 — variable names only. Never store real secrets in this file.",
    "# Values must be created in the destination environment.",
    ...[...envNames].sort().map((name) => `${name}=`),
    "",
  ].join("\n");
  write("configuration/.env.example", envText);

  const commit = (await import("node:child_process")).execFileSync("git", ["rev-parse", "HEAD"], { cwd: projectRoot, encoding: "utf8" }).trim();
  write("GIT-COMMIT.txt", `${commit}\n`);
  write("MANUS-DEPENDENCY-INITIAL.md", `# Dépendances Manus / Forge — état initial\n\n| Composant | Statut | Preuve / remplacement nécessaire |\n|---|---|---|\n| Authentification OAuth Manus | dépendant | Remplacer par OIDC/OAuth standard ou mode local. |\n| Stockage Forge | dépendant | Exporter les objets puis adopter un stockage S3 compatible/direct. |\n| Uploads | dépendant | Adapter les routes à un client de stockage choisi. |\n| LLM, Data API, génération d’images, transcription, notifications | dépendant | Créer des adaptateurs ou les désactiver proprement. |\n| Cartes Google via proxy Forge | dépendant | Fournir une clé/proxy propre ou migrer vers une solution libre. |\n| WebSocket applicatif | portable avec adaptation | Code versionné ; contrat de session à valider hors OAuth Manus. |\n| Runtime Vite Manus | dépendant | Retirer ou conditionner le plugin de runtime et le correctif HMR. |\n| Code React/Express/tRPC/Drizzle | portable | Exige Node, pnpm, base MySQL/TiDB et configuration indépendante. |\n| Base TiDB | exportable sous condition | Le micro-corpus est exporté ici ; l’export intégral reste hors périmètre. |\n`);

  const manifest = {
    format: "PERFUMUM Recovery Proof v0.1",
    status: "micro-export read-only; not a complete backup",
    created_at_utc: new Date().toISOString(),
    git_commit: commit,
    source_database: {
      engine: "TiDB/MySQL-compatible",
      server_version: databaseVersion.version,
      database_name: databaseVersion.database_name,
      production_mutated: false,
    },
    selected_corpus: {
      plant_id: proofPlantId,
      label: "Ferula galbaniflua (galbanum)",
      table_counts: Object.fromEntries(Object.entries(sample).map(([name, rows]) => [name, rows.length])),
      total_rows: Object.values(sample).reduce((sum, rows) => sum + rows.length, 0),
      exclusions: ["users", "cookies", "tokens", "secrets", "analytics_events", "media binaries", "all unselected production rows"],
    },
    schema_reality: {
      real_base_tables: tableInventory.length,
      views_excluded_from_matrix: Number(viewCount.total),
      real_columns_in_base_tables: columnInventory.length,
      real_constraints: Number(constraintCount.total),
      constraint_column_rows: constraintInventory.length,
      drizzle_declarations_observed: declared.size,
      migrations_sql_observed: fs.readdirSync(path.join(projectRoot, "drizzle")).filter((name) => name.endsWith(".sql")).length,
    },
    assets: { inventory: "assets/variety-images-reference-inventory.csv", downloaded_media: false },
    download: "All files are ordinary filesystem artifacts and can be downloaded from the delivered archive or copied with standard tools.",
  };
  write("MANIFEST.json", jsonText(manifest));
} finally {
  await connection.end();
}

# État de l’art — laboratoire de visualisation PERFUMUM

**Date :** 2026-10-24  
**Corpus consolidé :** 26 références, toutes marquées vérifiées.  
**Méthode :** cette consolidation utilise exclusivement les champs transmis dans la demande. Aucune URL n’a été recherchée de nouveau et aucun `report_path` isolé n’a été lu ou présenté comme accessible. Les chemins sont conservés seulement comme métadonnées dans les exports.  
**Lecture :** « Faits vérifiés » = éléments du corpus reçu. « Transfert interprété » = proposition pour PERFUMUM, non propriété démontrée de l’œuvre. Les techniques absentes des champs restent non documentées.

## Fiches de références

### R01 — BL00D.MONEY · The Genocide Economy, Mapped

**Référence et médium.** Non identifié : aucun auteur/crédit nominatif n’est affiché dans la documentation publique consultée du projet.. Base de données éditorialisée et visualisation relationnelle interactive dans le navigateur.

**Faits vérifiés.** Une carte relationnelle sur canvas relie entités, flux et faits ; les liens distinguent les éléments confirmés par source primaire de ceux rapportés, et le clic ouvre fiches, relations chiffrées et sources. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** D3 7.9.0 est effectivement chargé ; un canvas unique est exposé et le code client observé contient des appels de simulation de forces et de zoom. Algorithmes précis, licence, dépôt et documentation technique : non documentés. Difficulté : **Élevée : graphes denses, interaction multi-états, 3D/optique et traçabilité locale à maintenir sans transformer des hypothèses olfactives en faits.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Auteur non attribuable publiquement ; techniques détaillées non documentées. Interface dense, texte petit et surcharge de nœuds. Aucune sensation, distance ou relation n’est fiable pour PERFUMUM sans protocole local. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Proposer un laboratoire local paramétrique : objets 3D transparents pour notes, accords, matières ou hypothèses ; liens étiquetés, niveaux de confiance, vues ORBIT/CLUSTERS/FLOW et fiches de provenance. Transfert interprétatif, sans carte perceptive présumée fiable ni matériel activé. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.bl00d.money/
- https://d3js.org/

### R02 — On Broadway

**Référence et médium.** Daniel Goddemeyer, Moritz Stefaner, Dominikus Baur et Lev Manovich, avec collaborateurs. Application interactive web et installation publique tactile Full HD (initialement exécutée hors ligne).

**Faits vérifiés.** Treize couches synchronisées — images, couleurs, indicateurs sociaux et mobilités — sont empilées verticalement et alignées sur un axe longitudinal de Broadway. La navigation va de la vue globale au cadrage de quartier puis au retour global. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Interface web/image-centrée conçue pour écran tactile Full HD hors ligne ; couches provenant d’Instagram, Twitter, Foursquare, Google Street View, taxis NYC et ACS. Bibliothèques de rendu, protocole tactile précis et 3D/optique : non documentés. Difficulté : **Moyenne à élevée : normalisation d’entrées hétérogènes, lisibilité de couches denses et performance multi-échelle.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Sources urbaines temporellement et spatialement hétérogènes ; ACS agrégé à 73 census tracts ; corrélations visuelles non causales. Chargement lent et instabilité en ligne signalés. Vue globale, zoom Midtown et Reset observés ; glissement/pincement et bascule de façade non vérifiés. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Proposer une colonne paramétrique commune à des essais : familles de matières, volatilité estimée, transparence, réglage de projection et confiance. Vues globale et locale interprétées, sans carte perceptive fiable. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.on-broadway.nyc/
- https://www.on-broadway.nyc/app/
- https://manovich.net/index.php/art/on-broadway
- https://truth-and-beauty.net/projects/on-broadway
- https://www.nypl.org/events/exhibitions/public-eye-175-years-sharing-photography

### R03 — Wind Map

**Référence et médium.** Fernanda Viégas et Martin Wattenberg. Logiciel interactif web ; visualisation dynamique sur carte des États-Unis.

**Faits vérifiés.** Des traînées cométaires animées forment un champ dense qui rend visibles direction, continuité et intensité relative de prévisions de vent de surface. La visite directe a relevé modal NOAA, vue nationale, légende, villes, clic local, mesure, coordonnées et zoom. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** HINT.FM documente une implémentation entièrement en HTML et JavaScript. Interpolation, nombre/durée des particules et rendu précis : non documentés. Difficulté : **Moyenne : système paramétrique local, projection et tests de lisibilité.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Wind Map traite de données vectorielles géographiques de vent, non de perception. Toute correspondance odeur–position, intensité ou trajectoire est interprétative, doit rendre paramètres/provenance/incertitude visibles et ne doit pas servir à la sécurité. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Transférer seulement la grammaire visuelle : trajectoires projetées dont des paramètres locaux explicités modulent densité, vitesse, turbulence et transparence, à travers transparences, volumes optiques et objets 3D inertes ; sans carte perceptive fiable. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- http://hint.fm/projects/wind/
- http://hint.fm/wind/
- https://www.moma.org/collection/works/163892

### R04 — Dear Data

**Référence et médium.** Giorgia Lupi et Stefanie Posavec. Projet annuel de visualisation de données analogique : cartes postales en papier, dessins manuels et envoi postal transatlantique.

**Faits vérifiés.** Pendant 52 semaines, chaque autrice observe et mesure un thème quotidien, le traduit à la main sur une carte postale et l’envoie à l’autre. Recto : trace visuelle ; verso : clé de lecture, adresse et affranchissement. Les autrices le définissent comme « personal documentary », non quantified self. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Collecte et mesure personnelles hebdomadaires, notation, dessin manuel, cartes postales, légendes/codes et circulation postale sont documentés. Captation olfactive, carte perceptive validée, projection, transparences, optique/3D, algorithmes et matériel activé : non documentés. Difficulté : **Moyenne : fabrication légère, mais protocole de collecte, légende et médiation nécessaires pour éviter une lecture objectivante.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Projet sur des données quotidiennes, non olfactives. Petit échantillon, mémoire et vocabulaire hétérogènes, codage interprétatif et confidentialité des récits. Le site a été vu en navigation textuelle/défilement ; un changement de DOM et un zoom non observable limitent le jugement responsive. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Faire correspondre deux personnes autour de traces olfactives situées et subjectives (moment, intensité auto-déclarée, contexte, association verbale), avec feuille/calque-légende. Afficher « trace située », non carte perceptive ou profil fiable ; aucun matériel actif requis. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.dear-data.com/theproject
- https://www.dear-data.com/thebook
- https://www.moma.org/collection/works/216739
- http://giorgialupi.com/dear-data

### R05 — Connected Worlds

**Référence et médium.** Design I/O, en collaboration avec le New York Hall of Science (NYSCI). Installation immersive interactive muséale : projections panoramiques et au sol, bûches, gestes visiteurs et animations audiovisuelles.

**Faits vérifiés.** Écosystème interactif ouvert au NYSCI en 2015 : six habitats reliés par sol interactif, cascade et ressource en eau limitée. Les bûches détournent l’eau, les gestes plantent des graines et la santé conditionne créatures, migrations et réactions en chaîne. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Sept écrans, projection au sol, suivi de localisation, détection gestuelle, bases de données environnementales/sociales et openFrameworks sont documentés. Capteurs, projecteurs, calibration, algorithmes et règles exactes : non documentés. Difficulté : **Élevée pour une reprise immersive complète ; moyenne pour une maquette visuelle locale non interactive.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucun matériel actif dans le contexte PERFUMUM et aucune carte perceptive présumée. Interaction physique non testable à distance ; making-of Vimeo bloqué par anti-robot ; zoom non proposé/documenté. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Ne pas transposer une carte odeur-couleur-forme. Transférer la grammaire de relations : dépendances, stock commun et conséquences différées entre variables de formules/accords, rendues en projection, transparences et objets 3D/optique. États = paramètres de prototype, non ressenti mesuré. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.design-io.com/projects/connectedworlds
- https://nysci.org/press-releases/connected-worlds-press-release
- https://openframeworks.cc/
- https://vimeo.com/131665883

### R06 — Listening Post

**Référence et médium.** Mark Hansen et Ben Rubin. Installation audiovisuelle : grille suspendue de 231 modules-écrans, tubes fluorescents sous vide, électronique, logiciel et audio huit canaux.

**Faits vérifiés.** Des fragments en temps réel de forums publics sont affichés et lus ou chantés par synthèse vocale. Six mouvements combinent texte, son et musique selon des logiques distinctes. L’observation web a porté sur un carrousel photographique, non la restitution installative. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Écrans électroniques/tubes vacuum-fluorescent, contrôle informatique, logiciels d’installation/opération et huit canaux audio sont documentés. Filtrage, spatialisation précise, synthèse vocale et mapping : non documentés. Difficulté : **Moyenne pour une projection locale ; élevée pour un équivalent multi-écrans et audio spatial.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Flux publics : enjeux de contenu. Algorithmes originaux insuffisamment documentés et interactivité visiteur non explicitement décrite. États observés : archive web documentaire, pas installation. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Faire évoluer une matrice éditable de fragments olfactifs entre apparition, accumulation, regroupement et raréfaction. Une grille translucide peut suggérer une profondeur, mais les relations restent des hypothèses, non une carte perceptive ou mesure fiable. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.earstudio.com/projects/project-page/listening-post
- https://exhibits.library.cornell.edu/signaltocode/catalog/164-10981
- https://collection.sciencemuseumgroup.org.uk/objects/co8091687/listening-post
- https://whitney.org/exhibitions/listening-post
- https://vimeo.com/147750678

### R07 — The Great Animal Orchestra

**Référence et médium.** United Visual Artists (UVA) avec Bernie Krause. Installation audiovisuelle immersive : spectrogrammes, son, eau noire réfléchissante et rides produites par haut-parleurs.

**Faits vérifiés.** Des spectrogrammes issus des soundscapes de Bernie Krause deviennent un paysage projeté ; la Fondation Cartier documente aussi une transposition des données en particules lumineuses dans une installation électronique tridimensionnelle. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Spectrogrammes, projection, particules lumineuses, nappe d’eau noire et haut-parleurs générant des rides sont documentés. Logiciel, mapping, modèles matériels, capteurs et spatialisation : non documentés. Difficulté : **Moyenne à élevée : choix/traçabilité des variables, contrôle des superpositions et prévention d’une fausse équivalence forme/couleur–odeur.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Le site UVA a été inspecté (galerie, zoom et navigation), mais Vimeo n’a pas chargé après Play : aucune lecture attestée. Le site documente, sans reproduire l’installation. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Chaîne explicitement non scientifique : signal ou métadonnées déclarées → traces lumineuses → reflets dans transparences et volumes optiques passifs. Rendre provenance et incertitude visibles ; ne pas revendiquer une carte perceptive. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.uva.co.uk/features/great-animal-orchestra-cartier-foundation
- https://www.fondationcartier.com/en/program/exhibition/the-great-animal-orchestra-180-the-strand-london
- https://www.pem.org/exhibitions/the-great-animal-orchestra-bernie-krause-and-united-visual-artists
- https://www.biennaleofsydney.art/participants/the-great-animal-orchestra/

### R08 — data-verse 1, 2, 3

**Référence et médium.** Ryoji Ikeda. Trilogie d’installations audiovisuelles immersives (2019, 2019, 2020).

**Faits vérifiés.** Des projections de données à grande échelle associées au son font varier les représentations entre micro- et macro-échelles. Les visualisations sont liées notamment aux théories mathématiques et à la physique quantique ; jeux de données et algorithmes détaillés ne sont pas publiés. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Pour chaque volet : projecteur DCI-4K DLP, ordinateur, haut-parleurs ; minimum documenté de 10,24 m × 5,4 m. Infographie et programmation créditées à Norimichi Hirakawa, Tomonaga Tokuyama, Satoshi Hama et Ryo Shiraki. Difficulté : **Élevée : projection DCI-4K, synchronisation audiovisuelle et développement graphique spécialisé attestés.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Page artiste blanche/minimale dans le navigateur mais archive officielle vérifiée. Page High Museum = médiation web ; Vimeo documente des états et un avertissement stroboscopique, pas une interactivité de l’œuvre. Algorithmes, données, calibration, niveaux sonores et interaction : non documentés. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Transférer le séquençage d’échelles visuelles : trois régimes paramétriques locaux (particules, trajectoires, formes lentes) à travers transparences/objets optiques, avec entrées de séance déclarées. Ne promettre ni son, stroboscope, capteur ni réponse à l’odeur. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.ryojiikeda.com/archive/works/
- https://www.audemarspiguet.com/us/en/news/art/ryoji-ikeda-data-verse-atlanta
- https://high.org/exhibition/ryoji-ikeda/
- https://vimeo.com/566111687

### R09 — Black Rain

**Référence et médium.** Semiconductor — Ruth Jarman et Joe Gerhardt. Œuvre vidéo monochrome à canal unique + installation ; extrait HD de 3 min, boucle annoncée de 17 min ; son stéréo, 16:9.

**Faits vérifiés.** Des données d’imagerie HI de la mission solaire STEREO sont matière visuelle : champ granuleux, points lumineux, halos et traînées rendent perceptibles vent solaire, CME et artefacts de capture. Le site officiel a été inspecté avec ses contrôles vidéo. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Imagerie HI/STEREO, vidéo HD noir et blanc, son stéréo et projection/installation à canal unique. Logiciels, pipeline, paramètres de projection, dimensions, luminance et dispositif spatial : non documentés. Difficulté : **Moyenne : principe visuel transposable localement, reconstitution fidèle limitée faute de montage et paramètres d’exposition.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** L’extrait web ne couvre que trois minutes, non la boucle de 17 minutes ni l’exposition complète. Les formes ne sont ni code olfactif ni visualisation recalculable ; composante olfactive et interactivité parfumée non documentées. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Projection monochrome paramétrique avec transparences, volumes optiques et bruit/particules pour une trace instrumentale. Une note saisie manuellement peut moduler densité, persistance et dérive, sans carte perceptive, donnée scientifique, capteur ou diffuseur. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://semiconductorfilms.com/art/black-rain/
- https://science.nasa.gov/mission/stereo/
- https://lux.org.uk/work/black-rain/
- https://www.vdb.org/titles/black-rain

### R10 — Order From Chaos

**Référence et médium.** Maxime Causeret. Clip musical / animation procédurale audiovisuelle.

**Faits vérifiés.** Vidéo de Max Cooper créée par Maxime Causeret : passage de gouttes et structures chaotiques vers cellules, colonies, essaims, réaction-diffusion et formes concurrentes. Méthode itérative : croquis, systèmes dynamiques, montage musical, prévisualisation rapide. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Houdini ; fluide 2D, advection de texture, rides et mousse ; lignes guidées par particules/rééchantillonnées par image ; répulsion entre rides ; créatures avec forces/objectifs, Bullet et contraintes cone twist. Paramètres, rendu, shaders, caméra, compositing et optique : non documentés. Difficulté : **Moyenne à élevée : préserver une lecture stable au fil des itérations, sans simuler biologie ou olfaction.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucune relation à l’olfaction ni carte perceptive. Le titre concerne morceau et clip, précisément identifié. Le site a montré couverture, texte et contrôles Vimeo ; survol/zoom sans effet discernable. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Faire évoluer contours translucides, lignes et amas 2D dans trois états lisibles (chaos, agrégation, spécialisation), seulement avec données olfactives déclarées. Projection/transparence/optique servent la mise en espace, sans carte perceptive ni matériel actif. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://maxcooper.net/order-from-chaos
- https://vimeo.com/196269431
- https://www.gridmarkets.com/maxime-causeret

### R11 — Probability Lattice (intitulé demandé « Data sculpture » ambigu)

**Référence et médium.** Marius Watz. Objets paramétriques physiques, documentés par photographies sur une fiche web statique.

**Faits vérifiés.** « Data sculpture » est un terme de conférence, non un titre retrouvé. Projet retenu : Probability Lattice (2012), objets paramétriques typiquement 14 × 14 × 14 cm, ABS, MakerBot Replicator. Six vues fixes observées, sans contrôle de l’œuvre. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Paramétrique au niveau déclaré, ABS et impression 3D sur MakerBot Replicator. Logiciel, algorithme, données, règles probabilistes et post-traitement : non documentés. Difficulté : **Moyenne à élevée : grammaire paramétrique lisible, seuils de variation et médiation sans mesure objective de l’odeur.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucun mapping odeur→forme ni donnée source. ABS/MakerBot appartiennent à Watz et ne prescrivent pas PERFUMUM. Pas de modèle 3D manipulable ; titre demandé ambigu. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Employer des valeurs locales comme paramètres visuels de volumes virtuels : densité de maillage, ouverture, épaisseur apparente, dispersion. Montrer des variantes fixes par projection/transparence, sans carte perceptive ni interaction matérielle. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://mariuswatz.com/2012/05/09/probability-lattice/
- https://mariuswatz.com/bio
- https://mariuswatz.com/category/works/
- https://mariuswatz.com/2011/12/05/open-objects-the-future-of-things-lecture/

### R12 — Hyphae Lamps

**Référence et médium.** Nervous System (Jessica Rosenkrantz et Jesse Louis-Rosenberg). Luminaires sculpturaux génératifs : réseau ajouré imprimé en 3D (nylon/SLS), éclairé par LED.

**Faits vérifiés.** Hyphae Lamps (2011), et non toute la collection : lampes générées depuis un volume de base et points-racines ; réseau croissant dans un environnement de sources d’auxine, ramification et fusion. Le studio décrit logiciel C++/CGAL et production SLS à la demande. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** C++, CGAL, Cinder ; simulation inspirée de l’auxin flux canalization et Runions et al. ; Delaunay/voisinages, surface implicite et maillage CGAL ; SLS, nylon et LED Cree (3 LED, 3,6 W annoncés). Difficulté : **Élevée pour une réimplémentation fidèle ; moyenne pour prototype inspiré du principe de croissance.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Règles, paramètres, code, maillages et réglages de fabrication non publiés. Vidéo bloquée au chargement. Aucune traduction olfactive, topologie-perception validée ou protocole sensoriel documenté. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Utiliser le principe de croissance, non une équivalence odeur-forme : graphe de sources paramétriques abstraites (densité, bifurcation, fusion, fermeture), projeté ou rendu en transparences/objets 3D passifs, confronté à des échantillons sans carte perceptive présumée. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://n-e-r-v-o-u-s.com/projects/networks/hyphae/
- https://n-e-r-v-o-u-s.com/projects/networks/networks-sketches/
- https://n-e-r-v-o-u-s.com/blog/?p=1701
- https://n-e-r-v-o-u-s.com/blog/?p=1218
- http://algorithmicbotany.org/papers/venation.sig2005.html

### R13 — Computational Caustics

**Référence et médium.** EPFL — Computer Graphics and Geometry Laboratory (Yuliy Schwartzburg, Romain P. Testuz, Andrea Tagliasacchi, Mark Pauly ; Rayform SA, spin-off GCM). Optique computationnelle et objets 3D à forme libre : lentilles transparentes/réfraction et réflecteurs métalliques/réflexion, produisant des caustiques.

**Faits vérifiés.** Une image cible est obtenue par optimisation d’une surface : transport optimal source→cible, normales calculées par loi de Snell et optimisation itérative de la surface 3D. Prototypes publiés en PMMA fraisé CNC et poli. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** SIGGRAPH 2014 : transport optimal, discrétisation adaptative, surfaces lisses par morceaux, zones noires et concentrations. Rayform : surfaces CAD, PMMA/verre/cristal ou miroirs, sources dirigées petites/nettes et usinage de précision. Difficulté : **Élevée : géométrie inverse, rendu optique, contraintes de source ; fabrication/polissage précis pour réalisation matérielle.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Optique spéculaire parfaite, une surface/direction incidente par point ; sources étendues, diffusion et défauts ajoutent du flou ; auto-ombrage, réflexions internes et limites de réfraction non modélisés. Aucun lien odeur–forme–perception documenté. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Chaîne déclarative paramètres choisis → forme 3D simulée → projection visuelle, sans carte olfactive. Transparences, superpositions et instabilités matérialisent des relations de séance arbitraires ; contexte sans matériel activé. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.epfl.ch/labs/gcm/research-projects/computational-caustics/
- https://infoscience.epfl.ch/entities/publication/d13e8a01-c1e9-4e8e-ae52-f5cad3ada804
- https://infoscience.epfl.ch/bitstreams/361f310f-e863-4ae5-ad1c-4ca742a462e5/download
- https://rayform.ch/
- https://www.epfl.ch/labs/gcm/truth-arrives-in-slanted-beams/
- https://rayform.ch/truth-arrives-in-slanted-beams

### R14 — Your uncertain shadow (colour), 2010

**Référence et médium.** Olafur Eliasson. Installation lumineuse participative, dimensions variables/site-specific : cinq projecteurs colorés vers un mur blanc.

**Faits vérifiés.** Les cinq sources — deux vertes, magenta, orange et bleue — se combinent en lumière blanche. Le corps occulte chacune depuis un angle distinct et produit cinq silhouettes colorées, une ombre sombre et des recouvrements ; distance/déplacement modifient échelle et intensité. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Lampes HMI colorées, verre, aluminium, transformateurs et mur blanc/projection physique documentés. Logiciel, caméra/suivi, projection numérique, photométrie/colorimétrie détaillée, distances et plan électrique : non documentés. Difficulté : **Modérée pour maquette paramétrique ; élevée/non vérifiable pour réplique physique sans spécifications.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Titre ambigu entre variantes ; fiche limitée à (colour). L’expérience dépend de lumière additive, mur, corps et échelle réels. La galerie offre Images/Thumbnails/Information mais pas les paramètres physiques manquants. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Traduire une grammaire de superposition, pas une équivalence couleur-odeur : couches visuelles paramétriques, transparences et objet optique/3D séparables ou recouvrables selon le point de vue. Maquette locale sans mesure de l’odeur. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://olafureliasson.net/artwork/your-uncertain-shadow-colour-2010/
- https://tba21.org/your-uncertain-shadow
- https://laboralcentrodearte.org/en/artworks/your-uncertain-shadow-colour-2010-2/

### R15 — Solid Light Works (projet d’exposition, Pioneer Works, 2018)

**Référence et médium.** Anthony McCall. Installations de lumière projetée, brume fine, volumes spatiaux et parcours du visiteur ; six installations verticales et horizontales.

**Faits vérifiés.** Les volumes lumineux, issus d’un tracé bidimensionnel, évoluent dans le temps ; le spectateur mobile les explore comme formes à l’intersection de sculpture, cinéma et dessin. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Pour l’exposition 2018 : projection numérique, lumière projetée et fine brume sont documentées ; Pioneer Works documente salle occultée, brumeuse et haute. La liste technique détaillée de Skylight (2020) n’est pas généralisée à 2018. Difficulté : **Moyenne pour prototype visuel local ; élevée pour échelle architecturale avec projection, brume et déambulation.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Titre ambigu ; projet retenu = Pioneer Works 2018. Galerie observée sans zoom ni temporalité accessible ; les photos ne vérifient pas l’expérience spatiale complète. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Traduire une ligne paramétrique en volume 3D transparent animé par un curseur temporel (section, courbure, opacité), montré en vues orthogonales/perspective. Sans données, aucune forme/couleur/distance n’est attribuable aux notes. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.anthonymccall.com/solid-light-works
- https://pioneerworks.org/exhibitions/anthony-mccall-solid-light-works/
- https://hepworthwakefield.org/whats-on/anthony-mccall-solid-light-works/
- https://www.skny.com/exhibitions/anthony-mccall7

### R16 — Light Barrier (édition originale, 2014)

**Référence et médium.** Kimchi and Chips — Mimi Son et Elliot Woods. Miroirs convexes, projection et scanning.

**Faits vérifiés.** Des millions de faisceaux calibrés sont croisés via miroirs pour produire des objets graphiques lumineux flottants et animés ; la vidéo officielle qualifie le résultat de projection volumique formant des formes 3D dans l’espace. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Pour l’édition 2014 seulement : miroirs convexes, projection, scanning et faisceaux calibrés. Miroirs concaves, haze, 8 projecteurs, 630 sous-projecteurs, 16 millions pixels, 42 canaux audio et Rulr appartiennent à l’édition 2016 et sont exclus de 2014. Difficulté : **Élevée à très élevée pour reconstitution optique calibrée ; modérée pour prototype local projeté/translucide.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucune interaction par capteur, réaction au public ou carte perceptive documentée pour 2014. Détail technique insuffisant ; ne pas importer les spécifications 2015/2016. Zoom non vérifiable ; audio/plein écran observés, non activés. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Base olfactive seulement comme index paramétrique, sans correspondance objective : densité de traits, transparence, cadence et superposition varient entre apparition, concentration et dissipation. Référence conceptuelle/visuelle, pas effet volumétrique reproductible. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.kimchiandchips.com/works/lightbarrier/
- https://kimchiandchips.com/about
- https://www.signalfestival.com/en/history/2014/light-barrier/
- https://vimeo.com/100575793
- https://mab14.mediaarchitecture.org/awards/
- https://kimchiandchips.com/works/lightbarrier3

### R17 — DAYDREAM V.2

**Référence et médium.** NONOTAK (Noemi Schipfer et Takami Nakamoto). Installation audiovisuelle : lumière et son.

**Faits vérifiés.** La fiche officielle décrit des distorsions de l’espace par la relation espace virtuel/espace réel ; la lumière génère des espaces abstraits et le son leurs échos. La position du visiteur est frontale et passive. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Installation audiovisuelle, lumière et son documentés. Logiciel, moteur temps réel, contrôle, projecteurs, capteurs et interaction matérielle : non documentés. Difficulté : **Moyenne à élevée : lisibilité spatiale et transitions lentes à maintenir.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** « Daydream » désigne une série ; référence limitée à V.2 (2013). Vidéo YouTube bloquée par anti-bot, donc mouvement et son non vérifiés. Aucune technique 3D, optique, paramétrique ou olfactive non documentée ne doit être attribuée. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Employer une dramaturgie de seuils : expansion, compression, décalage, à travers plans transparents/objets 3D et projections sobres. Aucune carte olfactive ni relation odeur-image n’est présumée valide. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://nonotak.com/_DAYDREAM-V-2
- https://nonotak.com/ABOUT-CONTACT
- https://vimeo.com/79732146

### R18 — Acqua Alta

**Référence et médium.** Adrien M & Claire B (Claire Bardainne et Adrien Mondot). Triptyque (2019) : théâtre visuel, livre pop-up en réalité augmentée et expérience VR individuelle.

**Faits vérifiés.** Une fiction de montée des eaux est déclinée en scène avec danse/images vivantes, livre dessins-volumes révélé par RA et scène immersive en casque VR. La documentation décrit projections sur deux gazes et tapis de danse, images live, motion capture, papier pop-up, tablette RA et casque VR. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Projections vidéo, images générées/animées en direct, RA, application dédiée, VR, motion capture et ingénierie papier documentées. Logiciels, moteurs, capteurs, suivi RA et algorithmes corps-image : non documentés. Difficulté : **Moyenne à élevée : cohérence temporelle/paramétrique de couches, réglage de projection et transparence ; interaction corporelle et RA/VR non nécessaires au transfert.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Fiche, galerie et historique observés ; teaser Vimeo chargé sans lecture vérifiée ; zoom sans changement observable. Techniques non documentées signalées comme telles. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Faire répondre trois régimes d’un même état : particules projetées, volume 3D transparent/optique, couche noir-encre, paramètres partagés de densité/turbulence/montée/dissipation. Sans tablette, casque, matériel actif ni carte perceptive. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://adrien-m.net/projet/acqua-alta/
- https://ifdigital.institutfrancais.com/sites/default/files/media/AMCB-AQA-Overview.pdf

### R19 — Kacho Fugetsu -beauty in nature- (Real-Time Face Tracking & Projection Mapping, 2016)

**Référence et médium.** Nobumichi Asai (WOW). Installation audiovisuelle : projection sur visage, animation CG, maquillage et musique.

**Faits vérifiés.** Une base de maquillage reçoit des animations CG projetées sur le thème naturel kachōfūgetsu ; WOW le présente comme un projet de suivi facial et projection mapping en temps réel. Page officielle inspectée avec lecture, changement vidéo, menu et galerie. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Face tracking/projection mapping temps réel ; projecteur nouvellement conçu 4K/240P ; maquillage, CG et ingénierie de projection. Modèle de capteur, algorithme, logiciel, latence, calibration, luminance et géométrie : non documentés. Difficulté : **Élevée pour reproduire suivi/projection ; modérée pour prototype visuel local sans tracking.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Libellé initial ambigu ; fiche limitée à Kacho Fugetsu. Vidéo de démonstration insuffisante comme documentation d’ingénierie. Aucune carte olfactive fiable ni correspondance odeur-couleur publiée. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Principe surface-repère + couche projetée + variation temporelle sur objet 3D/translucide ou surface optique stable ; scènes A/B/C et familles visuelles traitées comme hypothèses révisables, sans carte, tracking ni équivalence odeur-couleur. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.w0w.co.jp/en/works/kacho_fugetsu
- https://www.w0w.co.jp/en/news/108
- https://d.nobumichiasai.com/ka-cho-fu-getsu

### R20 — LOTUS 7.0

**Référence et médium.** Studio Roosegaarde / Daan Roosegaarde. Mur interactif de centaines de feuilles d’aluminium ; la série indique aussi « smart foils, light, and other media ».

**Faits vérifiés.** Pour LOTUS 7.0, le passage d’une personne provoque le déploiement organique de centaines de feuilles et des vides transparents entre privé/public. La page de série documente aussi un matériau qui se replie/se déplie en réponse à la lumière. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Aluminium/smart foils, lumière, autres médias, comportement humain et ouverture des feuilles sont documentés. Capteurs, électronique, actionneurs, géométrie, calibration et cinématique : non documentés. Difficulté : **Moyenne pour traduction visuelle locale ; élevée pour imiter une matière réactive physique.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** « LOTUS » est une série ambiguë ; fiche isolée à 7.0, sans attribut des dômes ultérieurs. Site : vidéo d’en-tête, galerie/film/son et onglet Specifications ; aucun zoom. Matériel actif indisponible dans le contexte PERFUMUM. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Grammaire de révélation graduelle : modules-pétales 3D semi-transparents fermé/entre-ouvert/ouvert par scénario ou commande de séance. Objets optiques passifs et aucune interaction matérielle revendiquée. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.studioroosegaarde.net/project/lotus
- https://vimeo.com/18002972
- https://www.studioroosegaarde.net/projects

### R21 — Filament Sculptures: Generative Art as Physical Object

**Référence et médium.** LIA. Sculptures physiques génératives : imprimante 3D, G-code et filament ABS (2013–2015).

**Faits vérifiés.** Un logiciel sur mesure contrôle trois axes ; le filament s’auto-organise sous paramètres et produit surfaces/lignes allant du continu au chaotique, du rigide à l’organique. Site : image/texte, lecture vidéo puis vues d’exposition, sans interaction avec sculpture. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Imprimante 3D, G-code, ABS et logiciel personnalisé. « Strings and blobs », accumulation, parois sous-contraintes, effondrement naturel ; essais sur extrusion, vitesse et hauteur de tête documentés. Modèle, valeurs, langage logiciel et optique : non documentés. Difficulté : **Moyenne pour étude visuelle ; élevée pour simuler honnêtement thermoplasticité et gravité sans machine.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Physicalité, gravité et thermoplasticité constitutives et non transposables à la projection. Pas de zoom manipulable ni paramétrage visiteur ; durée du lecteur instable dans navigateur isolé. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Régime de contrainte (trame prescrite + relâchement émergent) transposé en filaments lumineux projetés, vus par transparences/optique passive. Juxtaposer continu/chaotique et rigide/organique ; association olfactive éditoriale, explicite, réversible, sans matériel actif. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.liaworks.com/stills-and-prints/filament-sculptures-generative-art-as-physical-object/
- https://vimeo.com/85913081
- https://liasomething.tumblr.com/archive
- https://www.liaworks.com/about/

### R22 — Wind Anemometer: Herring Cove, Cape Cod (2008), dans la section Changing Weather

**Référence et médium.** Nathalie Miebach. Sculpture en roseau, bois et données ; 68 × 40 × 37 pouces.

**Faits vérifiés.** « Weather data sculptures » est générique ; projet précis : œuvre/anémomètre de plage enregistrant des données de vent de Herring Cove Beach. Le tressage sert de grille tactile 3D de traduction de données scientifiques. La galerie a été observée, sans zoom ni légende interactive. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Roseau, bois, données, tressage de panier comme grille tactile 3D, et double fonction anémomètre/sculpture documentés. Capteurs, format/fréquence, schéma variable-forme-couleur, code, calibration et protocole de lecture : non documentés. Difficulté : **Élevée : publier règles de codage et maintenir l’incertitude visible.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucune équivalence stable odeur-géométrie ni carte perceptive. Relations d’autres œuvres non attribuées à celle-ci. Titre absent de l’état final de galerie mais présent dans le contenu complet ; technologie numérique spécifique non publiée. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Grille spatiale explicitée portant quelques variables locales/incertaines : volatilité estimée, famille, intensité déclarée et temps ; armature 3D transparente, fils/optique et projection de couches, sans capteur ni matériel activé. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.nathaliemiebach.com/work/new-portfolio-item-1
- https://www.nathaliemiebach.com/contact
- https://www.nathaliemiebach.com/

### R23 — Smellmap Amsterdam

**Référence et médium.** Kate McLean. Carte imprimée numérique (1 000 × 1 000 mm) et exposition multisensorielle participative ; visuels imprimés, 12 stimuli et post-it visiteurs.

**Faits vérifiés.** En avril 2013, 44 personnes ont réalisé 10 smellwalks en quatre jours et relevé plus de 650 perceptions. Lieu, description, attente, intensité, association et hédonique sont sélectionnés et visualisés par symboles ; portées/dérives sont des propositions situées. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Collecte manuscrite par smellwalk, symboles manipulés, impression, 11 odeurs synthétiques et parfum composite avec IFF ; Headspace ponctuel. Logiciel précis, 3D, projection, transparents et optique : non documentés. Difficulté : **Moyenne pour visualisation passive ; élevée pour reproduire l’installation olfactive dépendante d’IFF, itérations et parfois Headspace.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Perceptions subjectives, sélection et trajectoires interprétées, sources changeantes. WAF-425 dans navigateur sur accueil/About/URL ; vérification via pages officielles extractibles et texte primaire. Pas d’interaction web détectable. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Signes paramétriques de session, portées, dérives et notes verbatim projetés ou sur plan transparent ; objet 3D/optique passif séparant source, intensité et temps. États datés, hypothèse locale, sans localisation fiable ; exclure diffusion, synthèse et Headspace. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://sensorymaps.com/?projects=smellmap-amsterdam
- https://vis.cs.ucdavis.edu/vis2014papers/VIS_Conference/artShow/VISAP/18_McLean_Smellmap_VISAP2014.pdf
- https://sensorymaps.com/product/flower-explosion-spring-scents-smells-of-the-city-of-amsterdam-2013/
- https://sensorymaps.com/about/
- https://researchonline.rca.ac.uk/3945/

### R24 — Sissel Tolaas: RE_________

**Référence et médium.** Sissel Tolaas (scénographie : Formafantasma). Exposition-installation olfactive site-specific en « situations » et codes d’interprétation.

**Faits vérifiés.** Le projet diffère perception et explication : parcours libre de situations codées, puis titres/informations en salle finale. AirREborn relie odeur océanique dans ventilateur et intensité du vent visible par textiles. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Archivage/(re)production synthétique de molécules, archive annoncée de 10 000 molécules et lexique Nasalo ; 44 verres avec 44 molécules pour AL_earth_22 ; pour AirREborn, capteurs de côte, ventilateur et textiles. Site avec défilement, menu, carrousel et lightbox. Difficulté : **Élevée : traduire des données olfactives incertaines sans équivalence perceptive et sans matériel actif exclu.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** SMELL RE_searchLab est le laboratoire, non le titre : référence = RE_________. Formulation, sécurité, seuils de diffusion et algorithme de codage non détaillés. Lightbox sans zoom continu, modèle 3D ou interaction olfactive distante. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Grammaire code → exploration → explicitation ; volumes 3D/fioles inertes, transparences et projections pour origine, paramètre et incertitude. Tout flux est simulation visuelle déclarée ; ni diffusion, ventilateur, capteur temps réel ni matériel actif. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.afmuseet.no/en/exhibitions/sissel-tolaas-re________/
- https://formafantasma.com/work/sissel-tolaas-re
- https://icaphila.org/exhibitions/sissel-tolaas-re________/

### R25 — l’Artisan Électronique (titre « FLORA / Unfold » non vérifié et ambigu)

**Référence et médium.** Unfold — Claire Warnier et Dries Verbruggen — avec Tim Knapen. Installation participative : roue de potier virtuelle, projection/base de données, imprimante 3D céramique et objets imprimés.

**Faits vérifiés.** Les visiteurs modèlent virtuellement ; une sélection est périodiquement imprimée en argile et exposée. La fabrication couche par couche reprend le principe des colombins. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Imprimante 3D open source modifiée pour céramique ; roue virtuelle au moyen d’un scanner 3D et logiciel de conception ; collaboration RepRap. Paramètres, code, scanner, argile, cuisson et réglages : non documentés. Difficulté : **Élevée : interaction temps réel, géométrie paramétrique et scénographie ; réduction nécessaire à une variable visuelle et objets transparents inertes.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Aucun projet FLORA trouvé dans archive/présentation officielle : attribution demandée non affirmable. Œuvre vérifiée sur argile, non olfaction. Filtre ceramic = 404 ; zoom sans pourcentage/effet mesurable. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Chaîne lisible geste local → projection filaire translucide → variations de volumes 3D optiques → trace consultable, sans mesure ni équivalence forme–odeur et sans activation matérielle. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://unfold.be/
- https://unfold.be/archive.html
- https://unfold.be/pages/l-artisan-electronique.html
- https://vimeo.com/25195019

### R26 — Frequency and Volume (Relational Architecture 9, 2003)

**Référence et médium.** Rafael Lozano-Hemmer. Installation interactive de projection, suivi des ombres, son radiophonique et système multi-canal.

**Faits vérifiés.** Les ombres suivies par ordinateur balayent des fréquences radio par leur position et modulent le volume par leur taille ; l’œuvre annonce 150 kHz–1,5 GHz et jusqu’à 48 fréquences simultanées. Ce n’est pas une carte olfactive. Cette description est limitée aux faits fournis dans le corpus : elle ne valide aucune relation générale entre odeur, couleur, forme, espace ou intensité.

**Techniques documentées et difficulté.** Projecteurs, caméras, ordinateurs, scanners radioélectriques, antennes, radios et système sonore 48 canaux sont documentés par l’artiste ; SFMOMA confirme réponse aux ombres et équipement radio. Difficulté : **Élevée : évocation non activée possible, mais suivi d’ombres, scan radio, réception multi-bande et diffusion 48 canaux non transférables sans matériel/expertise/autorisations.**. Les procédés non explicitement décrits restent qualifiés de non documentés ; une étude de principe ne doit donc pas être assimilée à une réplique de l’œuvre.

**Limites.** Fiche/photothèque/visionneuse consultées ; vidéos avec contrôles mais lecture restée à 0:00. Pas de zoom ; calibration, algorithme de suivi, mapping, puissance, acoustique et accessibilité non documentés. Les observations navigateur éventuellement rapportées dans le corpus concernent la documentation web et ne remplacent pas l’expérience matérielle de l’œuvre.

**Transfert interprété vers PERFUMUM.** Employer projections, transparences et objet optique/3D pour densité, superposition ou expansion d’une hypothèse olfactive. Ne pas présenter les correspondances corps–volume, radio–parfum ou couleur–note comme établies. Il s’agit d’une proposition réversible pour un laboratoire local, et non d’un fait attribuable à l’œuvre. Toute correspondance sensorielle doit demeurer datée, sourcée, paramétrée et incertaine. **Note de consolidation.** Cette fiche n’extrapole ni détails d’implémentation, ni comportement physique, ni propriété sensorielle au-delà des champs reçus. Les écarts entre documentation, observation web éventuelle et proposition de laboratoire restent donc explicitement séparés à ce stade de travail.

**URLs fournies dans le corpus.**
- https://www.lozano-hemmer.com/frequency_and_volume.php
- https://www.sfmoma.org/exhibition/rafael-lozano-hemmer/

## Analyse comparative du corpus

Les vingt-six références constituent un corpus de grammaires de visualisation, et non un atlas scientifique de correspondances olfactives. Cette distinction est structurante : chaque transfert vers PERFUMUM doit séparer la donnée déclarée, la règle de traduction, le rendu visuel et l’interprétation vécue. Le corpus montre souvent des dispositifs à forte présence sensorielle — projection, son, lumière, matière ou interaction — sans documenter les algorithmes, calibrations ou paramètres permettant de les reproduire. L’absence d’information n’est donc pas un vide à combler par inférence : elle doit rester visible dans le laboratoire.

Un premier ensemble propose une architecture de données relationnelle et multi-échelle. BL00D.MONEY, On Broadway, Wind Map, Listening Post et le travail de Nathalie Miebach rendent transférables des opérations plutôt que des formes : distinguer des statuts de source, superposer des couches hétérogènes, passer d’une vue globale à une consultation locale, ou faire varier un champ selon des paramètres explicités. Dans PERFUMUM, cela peut devenir une fiche de séance avec matière, accord, formule, contexte, observation verbatim, provenance et confiance. BL00D.MONEY est pertinent pour l’étiquetage confirmé/rapporté ; On Broadway pour l’alignement de couches ; Wind Map pour la syntaxe des trajectoires ; Listening Post pour l’apparition, l’accumulation et la raréfaction ; Miebach pour l’obligation de publier le code de traduction. Aucune de ces références ne prouve une topologie perceptive de l’odeur.

Un deuxième ensemble soutient une dramaturgie paramétrique : Order From Chaos, Hyphae Lamps, Filament Sculptures, DAYDREAM V.2, data-verse et Acqua Alta. Agrégation, bifurcation, fusion, dissipation, compression, expansion et changement d’échelle peuvent être adoptés comme verbes de visualisation. En revanche, leur signification doit être locale et réversible. Une même séance peut ainsi être rendue sous trois régimes coordonnés — particules, trajectoires, volume lent — sans prétendre que l’un représente intrinsèquement une note ou une intensité. Cette approche est particulièrement adaptée à des prototypes où les paramètres sont déclarés par l’équipe plutôt qu’inférés d’un sensorium supposé universel.

Un troisième groupe travaille lumière, transparence, superposition et volume apparent : The Great Animal Orchestra, Computational Caustics, Your uncertain shadow, Solid Light Works, Light Barrier, Kacho Fugetsu, LOTUS 7.0 et Frequency and Volume. Le transfert robuste ne consiste pas à encoder l’odeur en couleur. Il consiste à employer recouvrement, angle, réfraction, ombre, densité de traits et point de vue pour différencier source, durée, hypothèse, niveau de confiance ou état de séance. Les références optiques et immersives rappellent cependant que la calibration, les conditions de source, la matière et l’échelle changent radicalement le résultat. Dans le contexte reçu, sans matériel activé, les objets transparents et optiques doivent rester passifs et les effets volumétriques doivent être annoncés comme simulés ou conceptuels.

Les deux références olfactives, Smellmap Amsterdam et RE_________, donnent les garde-fous les plus directs. McLean place la collecte dans un lieu, un moment et un vocabulaire subjectif ; Tolaas organise l’écart entre exploration et explicitation. Dear Data ajoute une éthique de la trace subjective et de la légende. Pour PERFUMUM, les sorties doivent donc afficher date, protocole, vocabulaire, auteur de l’observation, incertitude et version du paramétrage. Une « trace située » est plus défendable qu’une carte ou un profil sensoriel fiable.

Enfin, les œuvres participatives — Connected Worlds, l’Artisan Électronique, LOTUS 7.0, Kacho Fugetsu et Frequency and Volume — ne doivent pas conduire à promettre du tracking, de la ventilation, des capteurs, de la radio, de la diffusion ou un comportement matériel. Une commande manuelle ou un scénario temporel suffit à tester la relation visuelle. La synthèse opérationnelle est donc un laboratoire passif à trois vues coordonnées : carte relationnelle avec provenance, pile temporelle de couches, et volume/transparence paramétrique. Chaque vue doit afficher la nature des entrées, les règles de traduction, les limites et un statut explicite : observé, estimé, hypothèse ou inconnu. Les blocages de lecteurs, interfaces instables et fiches partielles rapportés par le corpus renforcent cette discipline : seules les informations reçues sont consolidées et aucune propriété non documentée n’est ajoutée.
